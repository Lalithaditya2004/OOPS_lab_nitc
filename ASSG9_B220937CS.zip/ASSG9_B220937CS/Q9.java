import java.util.List;

public class Q9 {
        public static void main(String[] args){  
        
        List<String> m = List.of("HIHI","OOSLab","KK","ASIF","Ajay","Aditya","BHAI");
        Integer s = m.stream().mapToInt(Q9::getcharSum).sum();
        System.out.println(s);
               
    }
    public static int getcharSum(String s){
        int c = s.chars().sum();
        return c;
    }


}

