import java.util.*;
import java.util.stream.Collectors;

public class Q7 {
    public static void main(String[] args){
        List<String> m = List.of("HIHI","OOSLab","KK","ASIF","Ajay","Aditya","BHAI");
        List<String> n = m.stream().filter(
            (s)->(s.charAt(0)=='A')
        ).collect(Collectors.toList());
        n.stream().forEach(System.out::println);
    }
}
