import java.util.*;

public class Q6 {
    public static void main(String[] args){
        List<String> m = List.of("HIHI","OOSLab","KK","ASIF","Ajay","Aditya","BHAI");
        m.stream().filter(
            (s)->(s.charAt(0)=='A')
        ).forEach(System.out::println);
    }
}
