import java.util.*;

public class Q3 {
    public static void main(String[] args){
        List<String> m = List.of("hihi","ooSLab","kk","Asif","Bhai");
        ArrayList<String> mn = new ArrayList<>();
        m.forEach((e)->{mn.add(e.toUpperCase());});
        mn.forEach(System.out::println);

    }
}
