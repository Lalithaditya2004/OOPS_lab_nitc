import java.util.*;
import java.util.function.*;
import java.util.stream.Collectors;

public class Q8 {
    public static void main(String[] args){  
        Predicate<String> FirstA = ((s)->(s.charAt(0)=='A'));
        
        List<String> m = List.of("HIHI","OOSLab","KK","ASIF","Ajay","Aditya","BHAI");
        List<String> n = m.stream().filter(
            FirstA
        ).collect(Collectors.toList());
        n.stream().forEach(System.out::println);
               
    }

}
