import java.util.*;
import java.util.stream.Collectors;

public class Q12 {
    public static void main(String[] args) {
        ArrayList<Student> s = new ArrayList<>();
        s.add(new Student("Aditya", 20));
        s.add(new Student("Asif", 22));
        s.add(new Student("Koushik", 19));
        s.add(new Student("Shravanthi", 19));
        s.add(new Student("Sai Teja", 16));
        s.add(new Student("Punneth", 30));
        s.add(new Student("Bhai", 30));
        Map<Integer,List<Student>> m = s.stream().collect(Collectors.groupingBy(Student::getAge));
        m.forEach((k,v)->{System.out.println(k+":");v.stream().forEach(System.out::println);});
    }    
}

class Student{
    public String name;
    public int age;
    Student(String n,int age){
        this.name = n;
        this.age = age;
    }
    public int getAge(){
        return this.age;
    }
    @Override
    public String toString(){
        return "Name: " +this.name + ", Age: " + this.age;
    }
}

class sortByAge implements Comparator<Student>{
    @Override
    public int compare(Student a,Student b){
        if(a.age > b.age){
            return 1;
        }
        else if(a.age < b.age){
            return -1;
        }
        return 0;
    }
}
