import java.util.*;

public class Q11 {
    public static void main(String[] args) {
        ArrayList<Student> s = new ArrayList<>();
        s.add(new Student("Aditya", 20));
        s.add(new Student("Asif", 22));
        s.add(new Student("Koushik", 19));
        s.add(new Student("Shravanthi", 19));
        s.add(new Student("Sai Teja", 16));
        s.add(new Student("Punneth", 17));
        s.add(new Student("Bhai", 30));
        s.add(new Student("Praval",34));
        s.add(new Student("Adal", 45));
        s.add(new Student("Bhuvan", 23));
        s.stream().sorted(new sortByAge()).forEach(System.out :: println);
    }    
}

class Student{
    public String name;
    public int age;
    Student(String n,int age){
        this.name = n;
        this.age = age;
    }

    @Override
    public String toString(){
        return "Name: " +this.name + ", Age: " + this.age;
    }
}

class sortByAge implements Comparator<Student>{
    @Override
    public int compare(Student a,Student b){
        if(a.age > b.age){
            return 1;
        }
        else if(a.age < b.age){
            return -1;
        }
        return 0;
    }
}
