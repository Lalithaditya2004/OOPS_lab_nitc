import java.util.*;
public class Q15 {
    public static void main(String[] args){
        Fruit Pineapple = new Fruit("Banana",60.0);
        Fruit Apple = new Fruit("Apple",260.0);
        Fruit Papaya = new Fruit("Papaya",120.0);
        Fruit Mango = new Fruit("Mango",75.0);
        Customer c1 = new Customer("Aditya", List.of(Mango,Papaya));
        Customer c2 = new Customer("Aditya", List.of(Pineapple,Papaya));
        Customer c3 = new Customer("Aamir", List.of(Mango,Apple));
        Customer c4 = new Customer("Ajay", List.of(Mango,Papaya,Apple));
        Customer c5 = new Customer("Puneeth", List.of(Mango,Papaya,Pineapple));
        Customer c6 = new Customer("Koushik", List.of(Mango));
        Customer c7 = new Customer("Adal", List.of(Apple,Mango));
        Customer c8 = new Customer("Sravanthi", List.of(Apple,Pineapple));
        Customer c9 = new Customer("Asif", List.of(Papaya));
        List<Customer> c = new ArrayList<>();
        c.add(c1);
        c.add(c2);
        c.add(c3);
        c.add(c4);
        c.add(c5);
        c.add(c6);
        c.add(c7);
        c.add(c8);
        c.add(c9);
        Double p = c.stream().mapToDouble((s)->(s.fruit.stream().mapToDouble(e->e.price_kg).sum())).sum();
        System.out.println(p);
    }
}


class Customer{
    public String name;
    public List<Fruit> fruit;
    public Customer(String n,List<Fruit> f){
        this.name = n;
        this.fruit = f;
    }
}

class Fruit{
    public String fruit;
    public Double price_kg;
    public Fruit(String n,Double p){
        this.fruit = n;
        this.price_kg = p;
    }
}
