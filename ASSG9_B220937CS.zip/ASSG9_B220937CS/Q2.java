import java.util.*;

public class Q2 {
    public static void main(String[] args){
        List<String> m = List.of("HIHI","OOSLab","KK","ASIF","BHAI");
        m.forEach(System.out::println);
    }
}
