import java.util.*;

public class Q5 {
    public static void main(String[] args){
       List<String> m = List.of("HIHI","OOSLab","KK","ASIF","BHAI");
       m.stream().map(String::length).forEach(System.out::println);
    }
}
