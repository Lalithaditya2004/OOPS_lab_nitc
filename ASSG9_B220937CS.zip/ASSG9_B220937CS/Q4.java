import java.util.*;

public class Q4 {
    public static void main(String[] args){
        List<String> m = List.of("hihi","ooSLab","kk","Asif","Bhai");
        m.stream().map(String::toUpperCase).forEach(System.out::println);
    }
}
