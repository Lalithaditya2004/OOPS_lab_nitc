import java.util.*;
public class Q13 {
    public static void main(String[] args) {
        ArrayList<Integer> n = new ArrayList<>();
        n.add(1);
        n.add(2);
        n.add(3);
        n.add(4);
        n.add(6);
        Integer s = n.stream().reduce(1,(a,b)->a*b);
        System.out.println(s);
    }
}
