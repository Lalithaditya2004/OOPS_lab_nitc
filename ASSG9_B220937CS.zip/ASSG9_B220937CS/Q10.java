
import java.util.ArrayList;

public class Q10 {
    public static void main(String[] args) {
        ArrayList<Student> s = new ArrayList<>();
        s.add(new Student("Aditya", 20));
        s.add(new Student("Asif", 22));
        s.add(new Student("Koushik", 19));
        s.add(new Student("Shravanthi", 19));
        s.add(new Student("Sai Teja", 16));
        s.add(new Student("Punneth", 17));
        s.add(new Student("Bhai", 30));
        s.add(new Student("Praval",34));
        s.add(new Student("Adal", 45));
        s.add(new Student("Bhuvan", 23));
        Double avg = s.stream().mapToInt((e)->(e.age)).average().orElse(0.0);
        System.out.println(avg);
        
    }
}

class Student{
    public String name;
    public int age;
    Student(String n,int age){
        this.name = n;
        this.age = age;
    }

    @Override
    public String toString(){
        return "Name: " +this.name + ", Age: " + this.age;
    }
}