import java.util.*;

public class Q14 {

    public static Student maxi(Student s1,Student s2){
        if(s1.age > s2.age) return s1;
        return s2;
    }
    public static void main(String[] args) {
        ArrayList<Student> s = new ArrayList<>();
        s.add(new Student("Aditya", 20));
        s.add(new Student("Asif", 22));
        s.add(new Student("Koushik", 19));
        s.add(new Student("Shravanthi", 19));
        s.add(new Student("Sai Teja", 16));
        s.add(new Student("Punneth", 17));
        s.add(new Student("Bhai", 30));
        Student neut = new Student("", 0);
        Student k = s.stream().reduce(Q14::maxi).orElse(neut);
        System.out.println(k);
        //k = s.stream().reduce(neut,(a,b)->(a.age > b.age ? a : b));
        
        
    }    
}

class Student{
    public String name;
    public int age;
    Student(String n,int age){
        this.name = n;
        this.age = age;
    }

    @Override
    public String toString(){
        return "Name: " +this.name + ", Age: " + this.age;
    }
}

class sortByAge implements Comparator<Student>{
    @Override
    public int compare(Student a,Student b){
        if(a.age > b.age){
            return 1;
        }
        else if(a.age < b.age){
            return -1;
        }
        return 0;
    }
}
