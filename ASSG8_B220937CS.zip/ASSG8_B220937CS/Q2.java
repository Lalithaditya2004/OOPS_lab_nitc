

public class Q2{
    public static void main(String[] args){
        DomesticShipment ds = new DomesticShipment(1500.0,1000.0,"Air");
        InternationalShipment is = new InternationalShipment(15000.0,10000.0,999.9);
        ExpressShipment es = new ExpressShipment(150.0,100.0,"Sea",9.99);
        ShippingCostCalculator cal = new ShippingCostCalculator();
        System.out.println("Domestic Shipment Cost: "+cal.calculateCost(ds));
        System.out.println("International Shipment Cost: "+cal.calculateCost(is));
        System.out.println("Express Shipment Cost: "+cal.calculateCost(es));
    }
}

class ShippingCostCalculator {

public double calculateCost(DomesticShipment shipment){
    return (shipment.Weight * 1.5) + (shipment.distance * 0.5);
}
public double calculateCost(InternationalShipment shipment){
    return (shipment.Weight * 2.0) + (shipment.distance * 0.8) +shipment.customsDuties;
}
public double calculateCost(ExpressShipment shipment){
    return (shipment.Weight * 1.5) + (shipment.distance * 0.5) +shipment.expressFee;
}

}


abstract class Shipment{
    public Double Weight;
    public Double distance;
    public Shipment(Double w,Double dist){
        this.Weight = w;
        this.distance = dist;
    }
}

class DomesticShipment extends Shipment{
    public String transportMode;
    public DomesticShipment(Double w,Double dist,String m){
        super(w,dist);
        this.transportMode = m;
    }

}
class InternationalShipment extends Shipment{
    public Double customsDuties;
    public InternationalShipment(Double w,Double dist,Double m){
        super(w,dist);
        this.customsDuties = m;
    }

}
class ExpressShipment extends DomesticShipment{
    public Double expressFee;
    public ExpressShipment(Double w,Double dist,String m,Double ex){
        super(w,dist,m);
        this.expressFee = ex;
    }

}
