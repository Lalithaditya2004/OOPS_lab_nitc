
import java.util.*;

public class Q1{
    public static void main(String[] args){
        MessController controller = new MessController();
        MealPLANi vegetarianPlan = new MealPLANi("Vegetarian Plan", 10.0);
        vegetarianPlan.addMenuItem(new MenuItem("Salad", 5.0));
        vegetarianPlan.addMenuItem(new MenuItem("Fruit", 3.0));
        controller.addMealPlan(vegetarianPlan);
        StudentImpl student1 = new StudentImpl("Alice", "S001");
        controller.subscribeStudentToMealPlan(student1, vegetarianPlan);
        controller.printSubscriptionStatus(student1);
    }
}

interface Person{
    public String getName();
    public String getID();
}

interface Student{
    public ArrayList<MealPLANi> getSubscribedMealPlans();
    public void subscribeMealPlan(MealPLANi mealPlan);
    public void unsubscribeMealPlan(MealPLANi mealPlan);
}

interface MealPlan{
    public String getPlanName();
    public ArrayList<MenuItem> getMenuItems();
    public Double getPrice();
}

class MealPLANi implements MealPlan{
    public String planName;
    public ArrayList<MenuItem> menuItems = new ArrayList<>();
    public Double price;
    public MealPLANi(String planName, Double price){
        this.planName = planName;
        this.price = price;
    }
    public void addMenuItem(MenuItem m){
        menuItems.add(m);
    }
    public void ListMenuItems(){
        for(MenuItem m : menuItems){
            System.out.println(m);
        }
    }
    @Override
    public String getPlanName(){
        return this.planName;
    }
    @Override
    public ArrayList<MenuItem> getMenuItems(){
        return this.menuItems;
    }
    @Override
    public Double getPrice(){
        // for(MenuItem m : menuItems){
        //     this.price += m.price;
        // }
        return this.price;
    }
    @Override
    public String toString(){
        return this.planName + ": " + this.price;
    }
}

class MenuItem {
    public String itemName;
    public Double price;
    public MenuItem(String n,Double p){
        this.itemName = n;
        this.price = p;
    }
    public String getItemName(){
        return this.itemName;
    }
    public Double getPrice(){
        return this.price;
    }
    @Override
    public String toString(){
        return this.itemName + ": $" + this.price;
    }
}

class StudentImpl implements Student,Person{
    public String name;
    public String ID;
    public ArrayList<MealPLANi> subscribedMealPlans = new ArrayList<>();
    public StudentImpl(String name,String id){
        this.name = name;
        this.ID = id;
    }
    @Override
    public void subscribeMealPlan(MealPLANi m){
        subscribedMealPlans.add(m);
    }
    @Override
    public void unsubscribeMealPlan(MealPLANi m){
        subscribedMealPlans.remove(m);
    }
    @Override 
    public String getName(){
        return this.name;
    }
    @Override 
    public String getID(){
        return this.ID;
    }
    @Override
    public ArrayList<MealPLANi> getSubscribedMealPlans(){
        return this.subscribedMealPlans;
    }
    
    
}

class MessController{
    ArrayList<MealPLANi> m = new ArrayList<>();
    public void addMealPlan(MealPLANi ml){
        this.m.add(ml);
    }
    public void subscribeStudentToMealPlan(StudentImpl s,MealPLANi ml){
        s.subscribeMealPlan(ml);
    }
    public void unsubscribeStudentToMealPlan(StudentImpl s,MealPLANi ml){
        s.unsubscribeMealPlan(ml);
    }
    public void printSubscriptionStatus(StudentImpl s){
        System.out.println(s.getName() + " is subscribed to the following meal plans:");
        ArrayList<MealPLANi> mls = s.getSubscribedMealPlans();
        for(MealPLANi i : mls){
            System.out.println(i);
        }
    }
}







