import java.util.*;

public class Q4{
    public static void main(String[] args){
        SavingsAccount s = new SavingsAccount("Aditya",10000.0);
        CheckingAccount c = new CheckingAccount("Sravanthi",1000.0);
        InternationalAccount i = new InternationalAccount("Anya",150000.0);

        s.withdraw(100.0);
        s.deposit(150.0);
        s.getMonthlyStatement();
        System.out.println("\n");
        c.withdraw(1500.0);
        c.deposit(200.0);
        c.getMonthlyStatement();
        System.out.println("\n");
        i.withdraw(5000.0);
        i.deposit(10000.0);
        i.getMonthlyStatement();


    }
}



interface Bank{
    public Double calculateInterest();
    public Double withdraw(Double amt);
    public void deposit(Double amt);
    public void getMonthlyStatement();
}

abstract class Account{
    public String AccountHolderName;
    public Double Balance;
    public int AccountNumber;
    private static int k = 1000;
    public Account(String name, Double balance){
        this.AccountHolderName = name;
        this.Balance = balance;
        this.AccountNumber = k+1;
        k++;
    }

}

class SavingsAccount extends Account implements Bank{
    public Double MinBalance = 100.0;
    List<String> txns = new ArrayList<>();
    public SavingsAccount(String n,Double b){
        super(n,b);
    }
    public void MinBalCheck(){
        if(this.Balance < this.MinBalance){
            Balance -= 10.0;
        }
    }

    @Override
    public Double calculateInterest() {
        return this.Balance*0.05*1;
    }

    @Override
    public Double withdraw(Double amt) {
        if(this.Balance >= amt){
            this.Balance -= amt;
            txns.add("Withdrew $"+amt+" from Account");
            return amt;
        }
        System.out.println("Withdrawal declined, No Sufficient balance to withdraw $"+amt);
        return 0.0;
    }

    @Override
    public void deposit(Double amt) {
        this.Balance += amt;
        txns.add("Deposited $"+amt);
    }

    @Override
    public void getMonthlyStatement() {
        System.out.println("Monthly Statement: ");
        for(String i : txns){
            System.out.println(i);
        }
        System.out.println("Gained a intrest of $"+this.calculateInterest());
    }
}

class CheckingAccount extends Account implements Bank{
    
    public Double overdraft = 0.0;
    public Double limit = 10000.0;
    public Double fee = 10.0;
    public List<String> txns = new ArrayList<>();
    public CheckingAccount(String n,Double b){
        super(n,b);
    }

    @Override
    public Double calculateInterest() {
       return overdraft*0.10*1;
    }

    @Override
    public Double withdraw(Double amt) {
       if(this.Balance < amt && amt<=(limit-overdraft)){
            txns.add("Withdrew $"+amt+" from Account");
            overdraft += (amt - this.Balance);
            this.Balance = 0.0;
            return amt;
       }
       else if(this.Balance >= amt){
            this.Balance -= amt;
            this.Balance -= fee;
            txns.add("Withdrew $"+amt+" from Account");
            txns.add("Charged $10.0 for withdrawal");
            return amt;
       }
       System.out.println("Requested amount is above overdraft limit");
        return 0.0;

    }

    @Override
    public void deposit(Double amt) {
       this.Balance += amt;
       txns.add("Deposited $"+amt);
    }

    @Override
    public void getMonthlyStatement() {
       System.out.println("Monthly Statement: ");
        for(String i : txns){
            System.out.println(i);
        }
        System.out.println("Overdue intrest: $"+this.calculateInterest());
    }
    
}

class InternationalAccount extends Account implements Bank{
    public List<String> txns = new ArrayList<>();
    public Double fee = 15.0;
    public InternationalAccount(String n,Double b){
        super(n,b);
    }

    @Override
    public Double calculateInterest() {
       return this.Balance*0.15*1;
    }

    @Override
    public Double withdraw(Double amt) {
       if(this.Balance >= amt){
            this.Balance -= amt;
            txns.add("Withdrew $"+amt+" from Account");
            return amt;
       }
       System.out.println("Withdrawal declined, No Sufficient balance to withdraw $"+amt);
        return 0.0;

    }

    @Override
    public void deposit(Double amt) {
       txns.add("Charged $15.0 for currency conversion from INR to USD");
       txns.add("Deposited $"+amt);
       this.Balance += amt*0.82;
    }

    @Override
    public void getMonthlyStatement() {
        System.out.println("Monthly Statement: ");
        for(String i : txns){
            System.out.println(i);
        }
        System.out.println("Gained a intrest of $"+this.calculateInterest());
    }
}

