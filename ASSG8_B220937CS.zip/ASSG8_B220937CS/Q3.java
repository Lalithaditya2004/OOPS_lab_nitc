import java.util.*;
import java.util.stream.Stream;

public class Q3{
    public static void main(String[] args) {
        List<String> stockBatch = List.of("AAPL", "GOOGL", "TSLA");
        StockProcessor stockProcessor = new StockProcessor("StockMarket", stockBatch);
        stockProcessor.loadData();
        stockProcessor.processData(); // Batch processing
        stockProcessor.aggregateData("Daily");
        // Real-time stock stream processing
        Stream<String> stockStream = Stream.of("AAPL", "AMZN", "TSLA");
        stockProcessor.processData(stockStream); // Real-time processing
        // TransactionProcessor instance
        System.out.println("\n");
        List<String> transactionBatch = List.of("TXN1", "TXN2", "TXN3");
        TransactionProcessor transactionProcessor = new
        TransactionProcessor("BankTransactions", transactionBatch); 
        transactionProcessor.loadData();
        transactionProcessor.processData(); // Batch processing
        transactionProcessor.aggregateData("User123", "High Risk");
        System.out.println("\n");
        // CryptoProcessor instance
        List<String> cryptoBatch = List.of("BTC", "ETH", "XRP");
        CryptoProcessor cryptoProcessor = new CryptoProcessor("CryptoExchange",cryptoBatch);
        cryptoProcessor.loadData();
        cryptoProcessor.processData(); // Batch processing
        cryptoProcessor.aggregateData(); // Currency-based aggregation
    }
}


interface DistributedDataProcessor{
    public void loadData();
    public void processData();
    public void aggregateData();
}


class StockProcessor implements DistributedDataProcessor{
    public String name;
    public List<String> stocks;
    public StockProcessor(String n,List<String> m){
        this.name = n;
        this.stocks = m;
    }

    @Override
    public void loadData() {
       System.out.println("Loading stock data..");
    }

    @Override
    public void processData() {
        System.out.println("Processing historical data of stocks: ");
        for(String i : stocks){
            System.out.println(i);
        }   
    }
    public void processData(Stream<String> s){
        System.out.println("Processing Real-time data of stocks: ");
        s.forEach(System.out::println);
    }

    @Override
    public void aggregateData() {
        System.out.println("Aggregating stock data..");
    }
    public void aggregateData(String timeframe){
        System.out.println("Aggregating stock data based on "+ timeframe + " timeframe..");
    }
    
}
class TransactionProcessor implements DistributedDataProcessor{
    public String name;
    public List<String> transactions;
    public TransactionProcessor(String n,List<String> m){
        this.name = n;
        this.transactions = m;
    }
    @Override
    public void loadData() {
       System.out.println("Loading transaction data..");
    }

    @Override
    public void processData() {
        System.out.println("Processing transactions : ");
        for(String i : transactions){
            System.out.println(i);
        }
    }
    

    @Override
    public void aggregateData() {
        System.out.println("Aggregating transaction data..");
    }
    
    public void aggregateData(String u,String risk){
        System.out.println("Aggregating transaction data based on UserId: "+ u + "\nAnalyzing potential risk based on risk score: "+risk);
    }

}
class CryptoProcessor implements DistributedDataProcessor{
    public String name;
    public List<String> cryptoBatch;
    public CryptoProcessor(String n, List<String> m){
        this.name = n;
        this.cryptoBatch = m;
    }

    @Override
    public void loadData() {
       System.out.println("Loading crypto currencies data..");
    }

    @Override
    public void processData() {
        System.out.println("Processing crypto currencies of: ");
        for(String i : cryptoBatch){
            System.out.println(i);
        }
    }
    

    @Override
    public void aggregateData() {
        System.out.println("Aggregating crypto currencies data..");
    }
    
}
