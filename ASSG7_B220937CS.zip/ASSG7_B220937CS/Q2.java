

public class Q2{
    public static void main(String[] args) {
        Student s = new Student("Aditya","Aditya@univ.com","B220937CS");
        Faculty f = new Faculty("Dr. Smith","smith@university.com","FAC001");
        System.out.println("\n --Student Access-- \n");
        s.accessPortal();
        System.out.println("\n --Faculty Access-- \n");
        f.accessPortal();
    }

}

class PlatformUser{
    
    private String name;
    private String email;
    private String UserId;
    public void accessPortal(){
        System.out.println("Name :" + name);
        System.out.println("Email :" + email);
        System.out.println("UserId :" + UserId);
        System.out.println("Portal Access : ");
    };
    public PlatformUser(String n,String email,String pass){
        this.name = n;
        this.email = email;
        this.UserId = pass;   
    }
}

class Student extends PlatformUser{
    public Student(String name, String email, String password) {
        super(name,email,password);
    }
    @Override
    public void accessPortal(){
        super.accessPortal();
        this.attendLiveSession();
        this.viewRecordedLectures();
        this.submitAssignment();
    }
    void attendLiveSession(){
        System.out. println("Viewing online courses.");
    }
    void viewRecordedLectures(){
        System.out.println("Attending live session.");
    }
    void submitAssignment(){
        System.out.println("Submitting assignments online.");
    }

}

class Faculty extends PlatformUser{

    public Faculty(String n,String email,String pass){
        super(n,email,pass);
    }
    
    @Override
    public void accessPortal(){
        super.accessPortal();
        this.uploadCourseMaterial();
        this.conductLiveSession();
        this.uploadAssignment();
        this.uploadRecordedLecture();
        
    }
    void conductLiveSession(){
        System.out.println("Conducting live online lecture.");
    }
    void uploadRecordedLecture(){
        System.out.println("Uploading recorded lectures");
    }
    void uploadCourseMaterial(){
        System.out.println("Uploading course material.");
    }
    void uploadAssignment(){
        System.out.println("Uploading an online assignment for students");
    }
}

