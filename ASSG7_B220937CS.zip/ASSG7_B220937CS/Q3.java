public class Q3{
    public static void main(String[] args) {


        // Full-time employee example with leave deduction and performance bonus
        FullTimeEmployee fullTimeEmployee = new FullTimeEmployee("Alice", 101, "Manager",50000.0, 2); 
        System.out.println("Full-Time Salary (Manager, after leave deduction): " + fullTimeEmployee.calculateSalary("Manager"));
        System.out.println("Full-Time Performance Bonus: " + fullTimeEmployee.calculatePerformanceBonus(92));



        // Part-time employee example with leave deduction and performance bonus
        PartTimeEmployee partTimeEmployee = new PartTimeEmployee("Bob", 102, 45, 20, 1);
        System.out.println("Part-Time Salary (with bonus, after leave deduction): " + partTimeEmployee.calculateSalary(45, true));
        System.out.println("Part-Time Performance Bonus: " + partTimeEmployee.calculatePerformanceBonus(87));
    }
}

abstract class Employee{
    private String name;
    private int id;
    public int leaveDays;
    abstract double calculateSalary();

    Employee(String n,int id,int leaves){
        this.name = n;
        this.id = id;
        this.leaveDays = leaves;
    }

    double calculateLeaveDeduction(int ld,double deduce){
        return deduce*ld;
    } 
}

class FullTimeEmployee extends Employee{
    String position;
    Double baseSalary;
    FullTimeEmployee( String name,int id,String position,Double sal,int leaves){
        super(name,id,leaves);
        this.position = position;
        this.baseSalary = sal;
    }


    @Override
    public double calculateSalary(){
        return baseSalary;
    }
    public double calculateSalary(String pos){
        if(pos.equals("Manager"))
            return baseSalary - this.calculateLeaveDeduction(this.leaveDays,1500.0);
        else if(pos.equals("CEO"))
            return baseSalary - this.calculateLeaveDeduction(this.leaveDays, 150000.0);
        return baseSalary - this.calculateLeaveDeduction(this.leaveDays,100.0);    
    }
    double calculatePerformanceBonus(double per){
        return (double)(per + 8)*20;
    }
    

    
}

class PartTimeEmployee extends Employee{
    int hoursWorked;
    double hourlyWage;
    PartTimeEmployee( String name,int id,int hoursWorked,int wage,int leaves){
        super(name,id,leaves);
        this.hoursWorked = hoursWorked;
        this.hourlyWage = wage;
    }
    @Override
    double calculateSalary(){
        return hoursWorked*hourlyWage;
    }
    double calculateSalary(int bonus,boolean leaveDed){
        if(leaveDed)
            return hourlyWage*hoursWorked+bonus-calculateLeaveDeduction(this.leaveDays,95.0 );
        return hourlyWage*hoursWorked+bonus; 
    }
    double calculatePerformanceBonus(double per){
        return (per+13)*5;
    }

}