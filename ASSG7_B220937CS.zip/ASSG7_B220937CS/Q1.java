
public class Q1{
    public static void main(String[] args) {
        SmartPhone s = new SmartPhone("Redmi Note 11 pro");
        System.out.println(s);
        s.powerOn();
        System.out.println(s);
        s.connectToNetwork("NITC-WIFI");
        System.out.println(s);
        s.disconnectFromNetwork();
        System.out.println(s);
    } 
}

interface PoweredDevice{
    void powerOn();
    void powerOff();
}

interface NetworkEnabled{
    void connectToNetwork(String netName);
    void disconnectFromNetwork();
}

class SmartPhone implements PoweredDevice,NetworkEnabled{
    String model;
    boolean isPoweredOn = false;
    String connectedNetwork = "None";
    SmartPhone(String m){
        this.model = m;
    }

    @Override
    public String toString(){
        return "Model: " + model + " ,Power State: " + isPoweredOn + " ,ConnectedNetwork: " + connectedNetwork;
    }

    @Override
    public void powerOff() {
        this.isPoweredOn = false;    
    }

    @Override
    public void connectToNetwork(String netName) {
        this.connectedNetwork = netName;    
    }

    @Override
    public void disconnectFromNetwork() {
        this.connectedNetwork = "None";    
    }

    @Override
    public void powerOn() {
        this.isPoweredOn = true;    
    }
    
}